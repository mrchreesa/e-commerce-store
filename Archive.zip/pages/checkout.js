import React from "react";
import PreviewPage from "../components/PreviewPage";

export default function checkout() {
  return (
    <div>
      <PreviewPage />
    </div>
  );
}
